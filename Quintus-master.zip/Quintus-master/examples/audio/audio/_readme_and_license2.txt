Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by NoiseCollector ( http://www.freesound.org/people/NoiseCollector/  )
You can find this pack online at: http://www.freesound.org/people/NoiseCollector/packs/647/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 41666__NoiseCollector__yamaha_Caug_ugly.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41666/
    * license: Attribution
  * 41665__NoiseCollector__yamaha_C9.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41665/
    * license: Attribution
  * 41664__NoiseCollector__yamaha_C7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41664/
    * license: Attribution
  * 41663__NoiseCollector__yamaha_C6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41663/
    * license: Attribution
  * 41662__NoiseCollector__yamaha_C.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41662/
    * license: Attribution
  * 41661__NoiseCollector__yamah_Cm_torture_position.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41661/
    * license: Attribution
  * 41660__NoiseCollector__yamah_Cm7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41660/
    * license: Attribution
  * 41659__NoiseCollector__yamah_Cm6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41659/
    * license: Attribution
  * 41658__NoiseCollector__yamah_Cm.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41658/
    * license: Attribution
  * 41657__NoiseCollector__yamah_Cdim.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/41657/
    * license: Attribution
  * 24279__NoiseCollector__yamaha_B.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24279/
    * license: Attribution
  * 24280__NoiseCollector__yamaha_B6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24280/
    * license: Attribution
  * 24281__NoiseCollector__yamaha_B7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24281/
    * license: Attribution
  * 24282__NoiseCollector__yamaha_B72.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24282/
    * license: Attribution
  * 24283__NoiseCollector__yamaha_B9.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24283/
    * license: Attribution
  * 24284__NoiseCollector__yamaha_Bb.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24284/
    * license: Attribution
  * 24285__NoiseCollector__yamaha_Bb6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24285/
    * license: Attribution
  * 24286__NoiseCollector__yamaha_Bb7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24286/
    * license: Attribution
  * 24287__NoiseCollector__yamaha_Bbm.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24287/
    * license: Attribution
  * 24288__NoiseCollector__yamaha_Bm.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24288/
    * license: Attribution
  * 24289__NoiseCollector__yamaha_Bm6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24289/
    * license: Attribution
  * 24290__NoiseCollector__yamaha_Bm7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24290/
    * license: Attribution
  * 24291__NoiseCollector__Yamaha_Baug.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24291/
    * license: Attribution
  * 24292__NoiseCollector__Yamaha_Bdim.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/24292/
    * license: Attribution
  * 15847__NoiseCollector__Abm.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15847/
    * license: Attribution
  * 15846__NoiseCollector__Abm_7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15846/
    * license: Attribution
  * 15845__NoiseCollector__Abm_6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15845/
    * license: Attribution
  * 15844__NoiseCollector__Abdim.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15844/
    * license: Attribution
  * 15843__NoiseCollector__Abaug.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15843/
    * license: Attribution
  * 15842__NoiseCollector__Ab_ouch.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15842/
    * license: Attribution
  * 15841__NoiseCollector__Ab_9.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15841/
    * license: Attribution
  * 15840__NoiseCollector__Ab_7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15840/
    * license: Attribution
  * 15839__NoiseCollector__Ab_6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15839/
    * license: Attribution
  * 15715__NoiseCollector__yamaha_Ab.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/15715/
    * license: Attribution
  * 14569__NoiseCollector__yamaha_Am7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14569/
    * license: Attribution
  * 14568__NoiseCollector__yamaha_Am6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14568/
    * license: Attribution
  * 14567__NoiseCollector__yamaha_Am.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14567/
    * license: Attribution
  * 14566__NoiseCollector__yamaha_Adim.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14566/
    * license: Attribution
  * 14565__NoiseCollector__yamaha_A7.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14565/
    * license: Attribution
  * 14564__NoiseCollector__yamaha_A6.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14564/
    * license: Attribution
  * 14562__NoiseCollector__yamaha_A_.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/14562/
    * license: Attribution
  * 12508__NoiseCollector__yamahfingerpluck.wav
    * url: http://www.freesound.org/people/NoiseCollector/sounds/12508/
    * license: Attribution

